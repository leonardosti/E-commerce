<?php
return [
    'prjName' => 'E-commerce-main',
    'basePath' => '/E-commerce-main/public/',
    'url' => 'http://localhost/E-commerce-main/public/',
    'css' => '/E-commerce-main/public/assets/style/style.css',
    'js' => '/E-commerce-main/public/assets/script/script.css',
];
