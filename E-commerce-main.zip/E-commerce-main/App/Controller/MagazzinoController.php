<?php

namespace Controller;

class MagazzinoController
{

}