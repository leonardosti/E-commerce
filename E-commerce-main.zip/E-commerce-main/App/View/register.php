<?php
?>
    <head>
        <title>Register</title>
    </head>
<?php include 'assets/header.php' ?>

    <!-- Content -->

<?php include 'assets/footer.php' ?>