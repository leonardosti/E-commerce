<?php
?>
<?php include 'assets/header.php' ?>

    <!-- Content -->

<?php include 'assets/footer.php' ?>