<?php

namespace Model;

class Magazzino
{

}