<?php

namespace Model;

class Abbonamento
{

}