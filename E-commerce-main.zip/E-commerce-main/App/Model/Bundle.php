<?php

namespace Model;

class Bundle
{

}