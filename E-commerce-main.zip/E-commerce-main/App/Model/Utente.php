<?php

namespace Model;

class Utente
{


}