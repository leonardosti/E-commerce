<?php

namespace Model;

class Ordine
{

}