<?php

namespace Model;

class Questionario
{

}